db.products.find()

db.products.find({name:"Apple"});
db.products.find({},{
    name:1
});


    db.products.update({_id: ObjectID("5ba87b6a861d020a8f289ec6")},
    {
        $set:{pid:1,
            
            pname:"Apple"
        },
        $unset: {id:1,name:"Apple" }
        
    })
    
    db.products.update({availability:"Out of Stock"},
    {
        $set:{quantity:0,
            
            pname:"Apple"
        },
        multi: true
        
    })
    
    
    //remove record
    db.products.remove({
        availability:"Out of Stock"
    })
    
    // to remove the show collections
    
    db.products.drop();
    db.products.find().count()
    db.products.count()
    
    //get specific record
    db.products.find().limit(2)
    db.products.find().skip(1).limit(1)
    //Asceding
    db.products.find().sort({ name:1 })
    //Descending
    db.products.find().sort({ name:-1 })
    //Sorting with 2 columns
    db.products.find().sort({ id:1, name:-1 })
    
    //Relational Operators
    //>-$gt,<-$lt,==-$eq,!=-$ne,<=-$lte,>= - $gte
    db.products.find({
        "quantity":{$gt:2}
    })
    
    db.products.find({
        "quantity":{$gte:5}
    })
    
     db.products.find({
        "quantity":{$eq:5}
    })
    db.products.find({
        "name":{$ne:"Apple"}
    })
    
    //Accessing nested document
    db.products.find({
        "category.name" :"fruit"
    }, 
    {
        name:1,
        "category.name":1
    }
    )
    //LogicalOperators
    db.products.find({
        $and:[
            {"category.name":"fruit"},{"Availability":"Available"}
        
            ]
    })
    
    db.products.find({
        $or: [
            {"category.cid":"C1"},{"category.cid":"C2"}
        
            ]
    })
    
    db.students.find({
            "marks":{$all: [50,70]}
        })
        
        //slice
        //get First 2 records
        
        db.students.find({},{
            "marks":{$slice:2}
        })
        
        //get last 2 records
        
        db.students.find({},{
            "marks":{$slice:-2}
        })
        // get records in betwen
         db.students.find({},{
            "marks":{$slice:[1,3]}
        })
        //Size operator - return the array which has the exact size
         db.students.find({"marks":{$size: 5}}
        )
        //Aggregate
         db.students.aggregate([
             {$group: { _id: "$location",totalStudents:{$sum:1}} }
             ])
             //Unwind
               
         db.students.aggregate([
             {$match: {location:"chennai"}},
             {$unwind:"$marks"  },
             {$group: { _id: "$_id",totalmark:{$sum:"$marks"}} }
             ])
             
             db.students.aggregate([
             {$match: {location:"chennai"}},
             {$unwind:"$marks"  },
             {$group: { _id: "$name",totalmark:{$sum:"$marks"}},
             }
             ])
             
             db.students.aggregate([
             {$match: {location:"chennai"}},
             {$unwind:"$marks"  },
             {$group: { _id: "$name",totalmark:{$sum:"$marks"}}},
             {$project: {name:"$_id",_id:0,totalMark:1}},
             {$sort: {totalmark:1}}
             ])
             
             //how many states are there in each region?
              db.states.aggregate([
             {$group: { _id: "$region",totalStates:{$sum:1}} }
             ])
             
             //how many states are there in each region and display its state names
             db.states.aggregate([
             {$group: { _id: "$region",totalStates:{$sum:1},states:{$push:"$name"}}},
             ])
             
             //to find all the areas of country
             db.states.aggregate([
             {$group: { _id: "$region",totalStates:{$sum:1},states:{$push:"$name"}}},
             ])
             
            
    
    db.products.insertMany([
       {
   "id":101,
   "name":"Apple" ,
   "price":25,
    "quantity" : 5,		
   "Availability" : "Available" ,  
    "category":{
		"cid":"C1",
		"name": "fruit",
		"description" : "Test apples"
		},
   "vendors":[
		{
			"vid":1,
			"name":"ABC Exports",
			"location":"Chennai"
		},
		{
			"vid":2,
			"name":"Muthu Exports",
			"location":"Madurai"
		}
	     ]
},

{
   "id":102,
   "name":"Orange" ,
   "price":25,
   "quantity" : 5,		
   "Availability" : "Available",   
   
   
    "category":{
		"cid":"C2",
		"name": "fruit",
		"description" : "Test apples"
		},
   "vendors":[
		{
			"vid":1,
			"name":"ABC Exports",
			"location":"Chennai"
		},
		{
			"vid":2,
			"name":"Muthu Exports",
			"location":"Madurai"
		}
	     ]
},
{
   "id":103,
   "name":"Grapes" ,
   "price":25,
   "quantity" : 5,		
   "Availability" : "Available",   
   
    "category":{
		"cid":"C3",
		"name": "fruit",
		"description" : "Test Grapes"
		},
   "vendors":[
		{
			"vid":1,
			"name":"ABC Exports",
			"location":"Chennai"
		},
		{
			"vid":2,
			"name":"Muthu Exports",
			"location":"Madurai"
		}
	     ]
}
,
{
   "id":104,
   "name":"Grapes" ,
   "price":25,
   "quantity" : 5,		
   "Availability" : "Out of Stock",   
   "category":{
		"cid":"C3",
		"name": "fruit",
		"description" : "Test Grapes"
		},
   "vendors":[
		{
			"vid":1,
			"name":"ABC Exports",
			"location":"Chennai"
		},
		{
			"vid":2,
			"name":"Muthu Exports",
			"location":"Madurai"
		}
	     ]
}

        ])
        
        db.createCollection("students")
        
        db.getCollectionNames()
        
        db.students.insert([{
            _id:1,
            name:"muthu",
            location:"chennai",
            marks:[50,61,70,75,45,65]
        }])
        
        db.students.insertMany([{
            _id:2,
            name:"prajeet",
            location:"chennai",
            marks:[75,61,71,73,70,70]
        },{
            _id:3,
            name:"umar",
            location:"karaikudi",
            marks:[50,61,70,75,40,60]
        },{
            _id:4,
            name:"rojieth",
            location:"chennai",
            marks:[80,81,80,85,80,87]
        },{
            _id:5,
            name:"kannan",
            location:"chennai",
            marks:[50,61,60,55,40,60]
        },{
            _id:6,
            name:"venki",
            location:"kovai",
            marks:[50,61,72,71,40,60]
        },{
            _id:7,
            name:"raj",
            location:"madurai",
            marks:[59,60,70,75,40,60]
        }])
        
        db.createCollection("states")
        db.getCollectionNames()
        
        
        
        
        
    